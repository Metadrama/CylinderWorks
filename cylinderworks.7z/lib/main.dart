import 'package:flutter/material.dart';

import 'native/engine_renderer_bindings.dart';
import 'native/engine_renderer_view.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  EngineRendererBindings.instance.loadIfNeeded();
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF08090D),
      ),
      home: const EngineRendererScreen(),
    );
  }
}

class EngineRendererScreen extends StatelessWidget {
  const EngineRendererScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          const Positioned.fill(
            child: EngineRendererView(),
          ),
          Positioned(
            left: 16,
            top: 48,
            right: 16,
            child: DecoratedBox(
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.35),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: const [
                    Text(
                      'CylinderWorks Renderer Prototype',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 8),
                    Text('• One finger drag: orbit camera'),
                    Text('• Two finger drag: pan target'),
                    Text('• Pinch: zoom'),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
