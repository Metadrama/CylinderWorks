#pragma once

#include <atomic>
#include <mutex>
#include <thread>

#include <android/native_window.h>
#include <android/native_window_jni.h>

#include "camera.h"
#include "egl_context.h"
#include "grid_plane.h"
#include "math_types.h"
#include "shader_program.h"

namespace engine {

class EngineRenderer {
public:
    EngineRenderer();
    ~EngineRenderer();

    bool SetSurface(ANativeWindow* window);
    void ClearSurface();

    void Resize(int width, int height);

    void Orbit(float deltaYaw, float deltaPitch);
    void Pan(float deltaX, float deltaY);
    void Zoom(float scaleDelta);

    void SetPreferredFrameRate(int fps);

    void Start();
    void Stop();

private:
    void InitializeGlResourcesLocked();
    void DestroyGlResourcesLocked();
    void ClearSurfaceLocked();

    void RenderFrame(int64_t frameTimeNanos);
    static void FrameCallback(long frameTimeNanos, void* data);

    void ScheduleNextFrame();
    void StartFallbackLoopLocked();
    void StopFallbackLoopLocked();
    void FallbackLoop();

    bool isRunning_{false};

    std::mutex mutex_;
    ANativeWindow* window_{nullptr};

    EglContext egl_{};
    OrbitCamera camera_{};
    ShaderProgram shader_{};
    GridPlane gridPlane_{};

    GLint uViewProj_{-1};
    GLint uModel_{-1};
    GLint uCameraPos_{-1};

    int width_{0};
    int height_{0};

    std::atomic<int> preferredFps_{60};

    // Timing
    std::atomic<int64_t> lastFrameTime_{0};

    std::thread fallbackThread_;
    std::atomic_bool fallbackThreadRunning_{false};
};

}  // namespace engine
