#include <jni.h>

#include <android/native_window_jni.h>
#include <android/log.h>
#include <new>
#include <cstdint>

#include "engine_renderer.h"

namespace {
constexpr const char* kTag = "EngineRenderer";

inline engine::EngineRenderer* FromHandle(jlong handle) {
    return reinterpret_cast<engine::EngineRenderer*>(handle);
}

inline engine::EngineRenderer* FromPointer(int64_t ptr) {
    return reinterpret_cast<engine::EngineRenderer*>(ptr);
}

template <typename T>
inline int64_t ToPointer(T* ptr) {
    return reinterpret_cast<int64_t>(ptr);
}

}  // namespace

extern "C" {

JNIEXPORT jlong JNICALL
Java_com_example_cylinderworks_engine_NativeBridge_nativeCreateRenderer(JNIEnv* env, jclass /*clazz*/) {
    auto* renderer = new (std::nothrow) engine::EngineRenderer();
    if (!renderer) {
        __android_log_print(ANDROID_LOG_ERROR, kTag, "Failed to allocate EngineRenderer");
        return 0;
    }
    return reinterpret_cast<jlong>(renderer);
}

JNIEXPORT void JNICALL
Java_com_example_cylinderworks_engine_NativeBridge_nativeDestroyRenderer(JNIEnv* env, jclass /*clazz*/, jlong handle) {
    auto* renderer = FromHandle(handle);
    if (!renderer) {
        return;
    }
    renderer->Stop();
    renderer->ClearSurface();
    delete renderer;
}

JNIEXPORT jboolean JNICALL
Java_com_example_cylinderworks_engine_NativeBridge_nativeSetSurface(JNIEnv* env, jclass /*clazz*/, jlong handle, jobject surface) {
    auto* renderer = FromHandle(handle);
    if (!renderer) {
        return JNI_FALSE;
    }

    ANativeWindow* window = nullptr;
    if (surface) {
        window = ANativeWindow_fromSurface(env, surface);
    }

    const bool result = renderer->SetSurface(window);
    if (window) {
        ANativeWindow_release(window);
    }

    return result ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_example_cylinderworks_engine_NativeBridge_nativeResize(JNIEnv* env, jclass /*clazz*/, jlong handle, jint width, jint height) {
    auto* renderer = FromHandle(handle);
    if (!renderer) {
        return;
    }
    renderer->Resize(width, height);
}

JNIEXPORT void JNICALL
Java_com_example_cylinderworks_engine_NativeBridge_nativeStart(JNIEnv* env, jclass /*clazz*/, jlong handle) {
    auto* renderer = FromHandle(handle);
    if (!renderer) {
        return;
    }
    renderer->Start();
}

JNIEXPORT void JNICALL
Java_com_example_cylinderworks_engine_NativeBridge_nativeStop(JNIEnv* env, jclass /*clazz*/, jlong handle) {
    auto* renderer = FromHandle(handle);
    if (!renderer) {
        return;
    }
    renderer->Stop();
}

JNIEXPORT void JNICALL
Java_com_example_cylinderworks_engine_NativeBridge_nativeOrbit(JNIEnv* env, jclass /*clazz*/, jlong handle, jfloat dx, jfloat dy) {
    auto* renderer = FromHandle(handle);
    if (!renderer) {
        return;
    }
    renderer->Orbit(dx, dy);
}

JNIEXPORT void JNICALL
Java_com_example_cylinderworks_engine_NativeBridge_nativePan(JNIEnv* env, jclass /*clazz*/, jlong handle, jfloat dx, jfloat dy) {
    auto* renderer = FromHandle(handle);
    if (!renderer) {
        return;
    }
    renderer->Pan(dx, dy);
}

JNIEXPORT void JNICALL
Java_com_example_cylinderworks_engine_NativeBridge_nativeZoom(JNIEnv* env, jclass /*clazz*/, jlong handle, jfloat delta) {
    auto* renderer = FromHandle(handle);
    if (!renderer) {
        return;
    }
    renderer->Zoom(delta);
}

JNIEXPORT void JNICALL
Java_com_example_cylinderworks_engine_NativeBridge_nativeSetPreferredFps(JNIEnv* env, jclass /*clazz*/, jlong handle, jint fps) {
    auto* renderer = FromHandle(handle);
    if (!renderer) {
        return;
    }
    renderer->SetPreferredFrameRate(fps);
}

JNIEXPORT void JNICALL
Java_com_example_cylinderworks_engine_NativeBridge_nativeClearSurface(JNIEnv* env, jclass /*clazz*/, jlong handle) {
    auto* renderer = FromHandle(handle);
    if (!renderer) {
        return;
    }
    renderer->ClearSurface();
}

}  // extern "C"

extern "C" {

int64_t engine_renderer_create() {
    auto* renderer = new (std::nothrow) engine::EngineRenderer();
    return ToPointer(renderer);
}

void engine_renderer_destroy(int64_t handle) {
    auto* renderer = FromPointer(handle);
    if (!renderer) {
        return;
    }
    renderer->Stop();
    renderer->ClearSurface();
    delete renderer;
}

void engine_renderer_resize(int64_t handle, int width, int height) {
    auto* renderer = FromPointer(handle);
    if (!renderer) {
        return;
    }
    renderer->Resize(width, height);
}

void engine_renderer_orbit(int64_t handle, float dx, float dy) {
    auto* renderer = FromPointer(handle);
    if (!renderer) {
        return;
    }
    renderer->Orbit(dx, dy);
}

void engine_renderer_pan(int64_t handle, float dx, float dy) {
    auto* renderer = FromPointer(handle);
    if (!renderer) {
        return;
    }
    renderer->Pan(dx, dy);
}

void engine_renderer_zoom(int64_t handle, float delta) {
    auto* renderer = FromPointer(handle);
    if (!renderer) {
        return;
    }
    renderer->Zoom(delta);
}

void engine_renderer_set_preferred_fps(int64_t handle, int fps) {
    auto* renderer = FromPointer(handle);
    if (!renderer) {
        return;
    }
    renderer->SetPreferredFrameRate(fps);
}

void engine_renderer_start(int64_t handle) {
    auto* renderer = FromPointer(handle);
    if (!renderer) {
        return;
    }
    renderer->Start();
}

void engine_renderer_stop(int64_t handle) {
    auto* renderer = FromPointer(handle);
    if (!renderer) {
        return;
    }
    renderer->Stop();
}

}  // extern "C"
